const aboutMeBtn = document.querySelector(".about-me__button-menu");
const aboutMeMenuList = document.querySelector(".about-me__menu-list");
const aboutMeItemList = document.querySelectorAll(".about-me-menu__item-list")

const locateBtn = document.querySelector(".locate__button-menu");
const locateMenuList = document.querySelector(".locate__menu-list");
const locateItemList = document.querySelectorAll(".locate-menu__item-list");

const conclusionBtn = document.querySelector(".conclusion__button-menu");
const conclusionMenuList = document.querySelector(".conclusion__menu-list");
const conclusionItemList = document.querySelectorAll(".conclusion-menu__item-list");

const dataProtectionBtn = document.querySelector(".data-protection__button-menu");
const dataProtectionMenuList = document.querySelector(".data-protection__menu-list");
const dataProtectionItemList = document.querySelectorAll(".data-protection-menu__item-list");

aboutMeBtn.onclick = function() {
    aboutMeBtn.classList.toggle("active");
    if (aboutMeBtn.classList.contains("active")){
        aboutMeMenuList.classList.replace("menu-list_disable", "menu-list_active");
        for (let elem of aboutMeItemList) {
            elem.classList.replace("item-list_disable", "item-list_active");
        }
    }
    else {
        aboutMeMenuList.classList.replace("menu-list_active", "menu-list_disable");
        for (let elem of aboutMeItemList) {
            elem.classList.replace("item-list_active", "item-list_disable");
        }
    }
}


locateBtn.onclick = function() {
    locateBtn.classList.toggle("active");
    if (locateBtn.classList.contains("active")){
        locateMenuList.classList.replace("menu-list_disable", "menu-list_active");
        for (let elem of locateItemList) {
            elem.classList.replace("item-list_disable", "item-list_active");
        }
    }
    else {
        locateMenuList.classList.replace("menu-list_active", "menu-list_disable");
        for (let elem of locateItemList) {
            elem.classList.replace("item-list_active", "item-list_disable");
        }
    }
}

conclusionBtn.onclick = function() {
    conclusionBtn.classList.toggle("active");
    if (conclusionBtn.classList.contains("active")){
        conclusionMenuList.classList.replace("menu-list_disable", "menu-list_active");
        for (let elem of conclusionItemList) {
            elem.classList.replace("item-list_disable", "item-list_active");
        }
    }
    else {
        conclusionMenuList.classList.replace("menu-list_active", "menu-list_disable");
        for (let elem of conclusionItemList) {
            elem.classList.replace("item-list_active", "item-list_disable");
        }
    }
}

dataProtectionBtn.onclick = function() {
    dataProtectionBtn.classList.toggle("active");
    if (dataProtectionBtn.classList.contains("active")){
        dataProtectionMenuList.classList.replace("menu-list_disable", "menu-list_active");
        for (let elem of dataProtectionItemList) {
            elem.classList.replace("item-list_disable", "item-list_active");
        }
    }
    else {
        dataProtectionMenuList.classList.replace("menu-list_active", "menu-list_disable");
        for (let elem of dataProtectionItemList) {
            elem.classList.replace("item-list_active", "item-list_disable");
        }
    }
}